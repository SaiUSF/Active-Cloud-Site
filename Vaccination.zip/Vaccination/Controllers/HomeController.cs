﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using Vaccination.Data;
using Vaccination.Models;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace Vaccination.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDBContext context;
        private readonly string Api = "https://data.cdc.gov/resource/rh2h-3yt2.json";
        public HomeController(ApplicationDBContext context)
        {
            this.context = context;
        }
        public async Task<IActionResult> Index()
        {
            context.RemoveRange(context.VaccineData);
            context.SaveChanges();
            IEnumerable<Vaccine>? vaccineList = new List<Vaccine>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(Api);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var response = await client.GetAsync("");
                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    Console.WriteLine(response.Content);
                    vaccineList = JsonConvert.DeserializeObject<List<Vaccine>>(result);
                    await context.VaccineData.AddRangeAsync(vaccineList);
                    context.SaveChanges();
                    return View();
                }
                else
                {
                    return View();
                }
            }
        }


        public ActionResult AboutUs()
        {
            return View();
        }


        public ActionResult Graph()
        {
            int count = context.VaccineData.Count();
            ViewBag.Count = count;
            return View();
        }

        public ActionResult LocationData()
        {
            IEnumerable<Vaccine> vaccineList = context.VaccineData;
            return View(vaccineList);
        }


        public ActionResult VaccineData()
        {
            IEnumerable<Vaccine> vaccineList = context.VaccineData;
            return View(vaccineList);
        }


        public ActionResult ViewSingle(int? id)
        {
            if (id == null || id == 0) return NotFound();
            Vaccine? p = context.VaccineData.Find(id);
            ViewBag.isEdit = false;
            return View("ViewSingle", p);
        }


        public ActionResult Add()
        {
            return View();
        }

        public ActionResult Edit(int? id)
        {
            if (id == null || id == 0) return NotFound();
            Vaccine? p = context.VaccineData.Find(id);
            ViewBag.isEdit = true;
            return View("ViewSingle", p);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null || id == 0) return NotFound();
            Vaccine? p = context.VaccineData.Find(id);
            context.VaccineData.Remove(p);
            context.SaveChanges();
            return RedirectToAction("VaccineData");
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Vaccine p)
        {
            if (p == null || p.Id == 0) return NotFound();
            context.VaccineData.Update(p);
            context.SaveChanges();
            return RedirectToAction("VaccineData");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Vaccine p)
        {
            if (p == null) return NotFound();
            if (ModelState.IsValid)
            {
                context.VaccineData.Add(p);
                context.SaveChanges();
                return RedirectToAction("VaccineData");
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Vaccination.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "VaccineData",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    date = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    mmwr_week = table.Column<int>(type: "int", nullable: false),
                    location = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    administered_daily = table.Column<int>(type: "int", nullable: false),
                    administered_cumulative = table.Column<long>(type: "bigint", nullable: false),
                    admin_dose_1_daily = table.Column<int>(type: "int", nullable: false),
                    admin_dose_1_cumulative = table.Column<long>(type: "bigint", nullable: false),
                    admin_dose_1_day_rolling = table.Column<int>(type: "int", nullable: false),
                    administered_dose1_pop_pct = table.Column<float>(type: "real", nullable: false),
                    date_type = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    administered_daily_change = table.Column<int>(type: "int", nullable: false),
                    administered_daily_change_1 = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    series_complete_daily = table.Column<int>(type: "int", nullable: false),
                    series_complete_cumulative = table.Column<long>(type: "bigint", nullable: false),
                    series_complete_day_rolling = table.Column<int>(type: "int", nullable: false),
                    series_complete_pop_pct = table.Column<float>(type: "real", nullable: false),
                    booster_daily = table.Column<int>(type: "int", nullable: false),
                    booster_cumulative = table.Column<long>(type: "bigint", nullable: false),
                    booster_7_day_rolling_average = table.Column<int>(type: "int", nullable: false),
                    additional_doses_vax_pct = table.Column<float>(type: "real", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VaccineData", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "VaccineData");
        }
    }
}

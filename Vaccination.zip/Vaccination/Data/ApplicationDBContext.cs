﻿using Microsoft.EntityFrameworkCore;
using Vaccination.Models;

namespace Vaccination.Data
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext (DbContextOptions options) : base(options)
        {

        }

        public DbSet<Vaccine> VaccineData { get; set; }
    }
}

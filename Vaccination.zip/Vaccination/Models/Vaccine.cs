﻿using System.ComponentModel.DataAnnotations;

namespace Vaccination.Models
{
    public class Vaccine
    {
        [Key]
        public int Id { get; set; }
        public string date { get; set; }
        public int mmwr_week { get; set; }
        public string location { get; set; }
        public int administered_daily { get; set; }
        public long administered_cumulative { get; set; }
        public int admin_dose_1_daily { get; set; }
        public long admin_dose_1_cumulative { get; set; }
        public int admin_dose_1_day_rolling { get; set; }
        public float administered_dose1_pop_pct { get; set; }
        public string date_type { get; set; }
        public int administered_daily_change { get; set; }
        public string administered_daily_change_1 { get; set; }
        public int series_complete_daily { get; set; }
        public long series_complete_cumulative { get; set; }
        public int series_complete_day_rolling { get; set; }
        public float series_complete_pop_pct { get; set; }
        public int booster_daily { get; set; }
        public long booster_cumulative { get; set; }
        public int booster_7_day_rolling_average { get; set; }
        public float additional_doses_vax_pct { get; set; }

    }
}
